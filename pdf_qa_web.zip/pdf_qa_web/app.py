import os
from flask import Flask, render_template, request, jsonify
from dotenv import load_dotenv
from utils import extract_text_from_pdf, chunk_text, create_vector_store, save_vector_store, load_vector_store
from langchain.chains import ConversationalRetrievalChain
from langchain_openai import ChatOpenAI

# Load API key
load_dotenv()
openai_api_key = os.getenv("OPENAI_API_KEY")

app = Flask(__name__)
qa_chain = None
chat_history = []

@app.route("/")
def index():
    return render_template("index.html")

@app.route("/upload", methods=["POST"])
def upload():
    global qa_chain, chat_history
    file = request.files["pdf"]
    if not file:
        return jsonify({"error": "No file uploaded"}), 400

    # Extract text from PDF
    text = extract_text_from_pdf(file)
    chunks = chunk_text(text)

    # Create embeddings + vectorstore
    vectorstore = create_vector_store(chunks)
    save_vector_store(vectorstore)

    retriever = vectorstore.as_retriever()
    llm = ChatOpenAI(temperature=0, model="gpt-3.5-turbo", openai_api_key=openai_api_key)
    qa_chain = ConversationalRetrievalChain.from_llm(llm, retriever)
    chat_history = []

    return jsonify({"message": "PDF processed successfully!"})

@app.route("/ask", methods=["POST"])
def ask():
    global qa_chain, chat_history
    data = request.json
    question = data.get("question")

    if not qa_chain:
        return jsonify({"error": "No PDF uploaded yet"}), 400

    result = qa_chain({"question": question, "chat_history": chat_history})
    answer = result["answer"]
    chat_history.append((question, answer))

    return jsonify({"question": question, "answer": answer})

if __name__ == "__main__":
    app.run(debug=True)
